const books = [
{
    id:1,
    title:"Modified-Book-25 ---The Universe and Dr. Einstein",
    year:2005,
    published:true
},
{
    id:2,
    title:"Book #2 ---- Einstein on politics",
    year:2013,
    published:true
},
{
    id:3,
    title:"Book #3 ---- Einstein versus the physical review",
    year:2005,
    published:false
},
{
    id:4,
    title:"Book #4 --- Einstein on peace",
    year:2017,
    published:true
},
{
    id:6,
    title:"Book #6 --- Book of Knowledge-2025-Oct-25",
    year:2017,
    published:true
}
];

const container = document.getElementById("papers-container");

books.forEach(book => {

    const card = document.createElement("div");
    card.classList.add("paper-card");

    card.innerHTML = `
        <div class="paper-icon">📄</div>

        <div class="paper-title">
            ${book.title}
        </div>

        <div class="paper-year">
            Year: ${book.year}
        </div>

        <div class="${book.published ? 'published' : 'unpublished'}">
            ${book.published ? 'Published' : 'Unpublished'}
        </div>
    `;

    container.appendChild(card);
});